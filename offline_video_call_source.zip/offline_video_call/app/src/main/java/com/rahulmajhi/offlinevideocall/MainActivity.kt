package com.rahulmajhi.offlinevideocall

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.rahulmajhi.offlinevideocall.databinding.ActivityMainBinding

@SuppressLint("MissingPermission")
class MainActivity : AppCompatActivity(), BluetoothManager.BluetoothEvents {

    private lateinit var binding: ActivityMainBinding
    private lateinit var bluetoothManager: BluetoothManager
    private lateinit var videoStreamer: VideoStreamer
    private lateinit var audioStreamer: AudioStreamer
    
    private val pairedDevices = mutableListOf<BluetoothDevice>()
    private val availableDevices = mutableListOf<BluetoothDevice>()
    private lateinit var pairedAdapter: DeviceAdapter
    private lateinit var availableAdapter: DeviceAdapter

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        checkPermissions()
        setupBluetooth()
        setupUI()
    }

    private fun checkPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        }

        val toRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (toRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, toRequest.toTypedArray(), 101)
        }
    }

    private fun setupBluetooth() {
        bluetoothManager = BluetoothManager(this, this)
        bluetoothManager.startServer()

        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        registerReceiver(receiver, filter)

        updatePairedDevices()
    }

    private fun setupUI() {
        pairedAdapter = DeviceAdapter(pairedDevices) { device ->
            bluetoothManager.connectToDevice(device)
        }
        availableAdapter = DeviceAdapter(availableDevices) { device ->
            bluetoothManager.connectToDevice(device)
        }

        binding.rvPairedDevices.layoutManager = LinearLayoutManager(this)
        binding.rvPairedDevices.adapter = pairedAdapter

        binding.rvAvailableDevices.layoutManager = LinearLayoutManager(this)
        binding.rvAvailableDevices.adapter = availableAdapter

        binding.btnScan.setOnClickListener {
            if (bluetoothAdapter?.isDiscovering == true) {
                bluetoothAdapter.cancelDiscovery()
                binding.btnScan.text = getString(R.string.scan_devices)
            } else {
                availableDevices.clear()
                availableAdapter.notifyDataSetChanged()
                bluetoothAdapter?.startDiscovery()
                binding.btnScan.text = getString(R.string.stop_scan)
            }
        }

        binding.btnEndCall.setOnClickListener {
            endCall()
        }

        binding.btnAccept.setOnClickListener {
            acceptCall()
        }

        binding.btnReject.setOnClickListener {
            binding.incomingCallOverlay.visibility = View.GONE
        }

        videoStreamer = VideoStreamer(this, this) { frame ->
            bluetoothManager.sendData(BluetoothManager.TYPE_VIDEO, frame)
        }

        audioStreamer = AudioStreamer { chunk ->
            bluetoothManager.sendData(BluetoothManager.TYPE_AUDIO, chunk)
        }
    }

    private fun updatePairedDevices() {
        pairedDevices.clear()
        bluetoothAdapter?.bondedDevices?.let { pairedDevices.addAll(it) }
        pairedAdapter.notifyDataSetChanged()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    device?.let {
                        if (!pairedDevices.contains(it) && !availableDevices.contains(it)) {
                            availableDevices.add(it)
                            availableAdapter.notifyDataSetChanged()
                        }
                    }
                }
            }
        }
    }

    override fun onDeviceConnected(device: BluetoothDevice) {
        runOnUiThread {
            binding.tvCallerName.text = device.name ?: device.address
            binding.incomingCallOverlay.visibility = View.VISIBLE
        }
    }

    private fun acceptCall() {
        binding.incomingCallOverlay.visibility = View.GONE
        binding.deviceListView.visibility = View.GONE
        binding.callView.visibility = View.VISIBLE
        
        videoStreamer.startCapture()
        audioStreamer.startRecording()
        audioStreamer.startPlaying()
    }

    private fun endCall() {
        videoStreamer.stopCapture()
        audioStreamer.stopRecording()
        audioStreamer.stopPlaying()
        bluetoothManager.stopAll()
        bluetoothManager.startServer()

        binding.callView.visibility = View.GONE
        binding.deviceListView.visibility = View.VISIBLE
    }

    override fun onDataReceived(type: Int, data: ByteArray) {
        when (type) {
            BluetoothManager.TYPE_VIDEO -> {
                val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size)
                runOnUiThread {
                    binding.remoteVideo.setImageBitmap(bitmap)
                }
            }
            BluetoothManager.TYPE_AUDIO -> {
                audioStreamer.playChunk(data)
            }
        }
    }

    override fun onDeviceDisconnected() {
        runOnUiThread {
            endCall()
            Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onConnectionFailed() {
        runOnUiThread {
            Toast.makeText(this, "Connection Failed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCallRequestReceived(device: BluetoothDevice) {
        // Handled in onDeviceConnected for simplicity in this version
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
        bluetoothManager.stopAll()
    }
}
