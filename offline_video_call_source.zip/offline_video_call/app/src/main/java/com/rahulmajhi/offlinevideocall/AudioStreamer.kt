package com.rahulmajhi.offlinevideocall

import android.annotation.SuppressLint
import android.media.*
import android.util.Log

@SuppressLint("MissingPermission")
class AudioStreamer(private val onAudioChunkReady: (ByteArray) -> Unit) {

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isRecording = false
    private var isPlaying = false

    private val sampleRate = 8000
    private val channelConfigIn = AudioFormat.CHANNEL_IN_MONO
    private val channelConfigOut = AudioFormat.CHANNEL_OUT_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfigIn, audioFormat)

    fun startRecording() {
        if (isRecording) return
        
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            channelConfigIn,
            audioFormat,
            bufferSize
        )

        isRecording = true
        audioRecord?.startRecording()

        Thread {
            val buffer = ByteArray(bufferSize)
            while (isRecording) {
                val read = audioRecord?.read(buffer, 0, bufferSize) ?: 0
                if (read > 0) {
                    val chunk = buffer.copyOfRange(0, read)
                    onAudioChunkReady(chunk)
                }
            }
        }.start()
    }

    fun stopRecording() {
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }

    fun startPlaying() {
        if (isPlaying) return

        audioTrack = AudioTrack(
            AudioManager.STREAM_VOICE_CALL,
            sampleRate,
            channelConfigOut,
            audioFormat,
            bufferSize,
            AudioTrack.MODE_STREAM
        )

        isPlaying = true
        audioTrack?.play()
    }

    fun playChunk(data: ByteArray) {
        if (isPlaying) {
            audioTrack?.write(data, 0, data.size)
        }
    }

    fun stopPlaying() {
        isPlaying = false
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }
}
