package com.rahulmajhi.offlinevideocall

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.*

@SuppressLint("MissingPermission")
class BluetoothManager(private val context: Context, private val listener: BluetoothEvents) {

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var serverThread: AcceptThread? = null
    private var clientThread: ConnectThread? = null
    private var connectedThread: ConnectedThread? = null

    companion object {
        private const val TAG = "BluetoothManager"
        private const val APP_NAME = "OfflineVideoCall"
        private val MY_UUID: UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
        
        const val TYPE_VIDEO = 1
        const val TYPE_AUDIO = 2
        const val TYPE_SIGNAL = 3
        
        const val SIGNAL_CALL_REQUEST = 101
        const val SIGNAL_CALL_ACCEPT = 102
        const val SIGNAL_CALL_REJECT = 103
        const val SIGNAL_CALL_END = 104
    }

    interface BluetoothEvents {
        fun onDeviceConnected(device: BluetoothDevice)
        fun onDeviceDisconnected()
        fun onDataReceived(type: Int, data: ByteArray)
        fun onConnectionFailed()
        fun onCallRequestReceived(device: BluetoothDevice)
    }

    fun startServer() {
        stopAll()
        serverThread = AcceptThread()
        serverThread?.start()
    }

    fun connectToDevice(device: BluetoothDevice) {
        stopAll()
        clientThread = ConnectThread(device)
        clientThread?.start()
    }

    fun sendData(type: Int, data: ByteArray) {
        val header = ByteArray(5)
        header[0] = type.toByte()
        val size = data.size
        header[1] = (size shr 24).toByte()
        header[2] = (size shr 16).toByte()
        header[3] = (size shr 8).toByte()
        header[4] = size.toByte()
        
        connectedThread?.write(header + data)
    }

    fun stopAll() {
        serverThread?.cancel()
        serverThread = null
        clientThread?.cancel()
        clientThread = null
        connectedThread?.cancel()
        connectedThread = null
    }

    private inner class AcceptThread : Thread() {
        private val mmServerSocket: BluetoothServerSocket? by lazy(LazyThreadSafetyMode.NONE) {
            bluetoothAdapter?.listenUsingInsecureRfcommWithServiceRecord(APP_NAME, MY_UUID)
        }

        override fun run() {
            var shouldLoop = true
            while (shouldLoop) {
                val socket: BluetoothSocket? = try {
                    mmServerSocket?.accept()
                } catch (e: IOException) {
                    Log.e(TAG, "Socket's accept() method failed", e)
                    shouldLoop = false
                    null
                }
                socket?.also {
                    manageConnectedSocket(it)
                    // mmServerSocket?.close() // Keep listening if we want multiple connections, but for P2P we can stop
                    // shouldLoop = false
                }
            }
        }

        fun cancel() {
            try {
                mmServerSocket?.close()
            } catch (e: IOException) {
                Log.e(TAG, "Could not close the connect socket", e)
            }
        }
    }

    private inner class ConnectThread(private val device: BluetoothDevice) : Thread() {
        private val mmSocket: BluetoothSocket? by lazy(LazyThreadSafetyMode.NONE) {
            device.createRfcommSocketToServiceRecord(MY_UUID)
        }

        override fun run() {
            bluetoothAdapter?.cancelDiscovery()

            try {
                mmSocket?.connect()
            } catch (e: IOException) {
                Log.e(TAG, "Connection failed", e)
                listener.onConnectionFailed()
                try {
                    mmSocket?.close()
                } catch (e2: IOException) {
                    Log.e(TAG, "Could not close the client socket", e2)
                }
                return
            }

            mmSocket?.also { manageConnectedSocket(it) }
        }

        fun cancel() {
            try {
                mmSocket?.close()
            } catch (e: IOException) {
                Log.e(TAG, "Could not close the client socket", e)
            }
        }
    }

    private fun manageConnectedSocket(socket: BluetoothSocket) {
        connectedThread = ConnectedThread(socket)
        connectedThread?.start()
        listener.onDeviceConnected(socket.remoteDevice)
    }

    private inner class ConnectedThread(private val mmSocket: BluetoothSocket) : Thread() {
        private val mmInStream: InputStream = mmSocket.inputStream
        private val mmOutStream: OutputStream = mmSocket.outputStream
        private val mmBuffer: ByteArray = ByteArray(1024 * 64) // 64KB buffer

        override fun run() {
            while (true) {
                try {
                    // Read header (5 bytes)
                    val header = ByteArray(5)
                    var bytesRead = 0
                    while (bytesRead < 5) {
                        val read = mmInStream.read(header, bytesRead, 5 - bytesRead)
                        if (read == -1) throw IOException("Stream closed")
                        bytesRead += read
                    }

                    val type = header[0].toInt()
                    val size = ((header[1].toInt() and 0xFF) shl 24) or
                               ((header[2].toInt() and 0xFF) shl 16) or
                               ((header[3].toInt() and 0xFF) shl 8) or
                               (header[4].toInt() and 0xFF)

                    if (size < 0 || size > 1024 * 1024) continue // Sanity check 1MB max

                    val payload = ByteArray(size)
                    var payloadRead = 0
                    while (payloadRead < size) {
                        val read = mmInStream.read(payload, payloadRead, size - payloadRead)
                        if (read == -1) throw IOException("Stream closed")
                        payloadRead += read
                    }

                    listener.onDataReceived(type, payload)

                } catch (e: IOException) {
                    Log.e(TAG, "Input stream was disconnected", e)
                    listener.onDeviceDisconnected()
                    break
                }
            }
        }

        fun write(bytes: ByteArray) {
            try {
                mmOutStream.write(bytes)
            } catch (e: IOException) {
                Log.e(TAG, "Error occurred when sending data", e)
            }
        }

        fun cancel() {
            try {
                mmSocket.close()
            } catch (e: IOException) {
                Log.e(TAG, "Could not close the connect socket", e)
            }
        }
    }
}
