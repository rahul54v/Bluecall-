package com.rahulmajhi.offlinevideocall

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rahulmajhi.offlinevideocall.databinding.ItemDeviceBinding

class DeviceAdapter(
    private val devices: List<BluetoothDevice>,
    private val onConnectClick: (BluetoothDevice) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>() {

    inner class DeviceViewHolder(val binding: ItemDeviceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val binding = ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DeviceViewHolder(binding)
    }

    @SuppressLint("MissingPermission")
    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        val device = devices[position]
        holder.binding.tvDeviceName.text = device.name ?: "Unknown Device"
        holder.binding.tvDeviceAddress.text = device.address
        holder.binding.btnConnect.setOnClickListener { onConnectClick(device) }
    }

    override fun getItemCount(): Int = devices.size
}
